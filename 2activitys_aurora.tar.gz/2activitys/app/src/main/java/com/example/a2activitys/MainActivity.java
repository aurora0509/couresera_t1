package com.example.a2activitys;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
EditText edtnombre,edtfecha,edtcorreo;
Button btnAgregar;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        edtnombre=(EditText)findViewById(R.id.edtNombre);
        edtfecha=(EditText)findViewById(R.id.edtFecha);
        edtcorreo=(EditText)findViewById(R.id.edtCorreo);
        btnAgregar=(Button) findViewById(R.id.btnAgregar);
        final datos datos=new datos(getApplicationContext());
        btnAgregar.setOnContextClickListener(new View.OnContextClickListener() {
            @Override
            public boolean onContextClick(View v) {
                datos.agregarFormulario(edtnombre.getText().toString(),edtfecha.getText().toString(),edtcorreo.getText().toString());
                Toast.makeText(getApplicationContext(), "se agrego correctamente",Toast.LENGTH_LONG).show();
                return false;
            }
        });
    }
//metodo boton siguiente
public void siguiente(View view){
    Intent siguiente = new Intent(this, edicion.class);
startActivity(siguiente);
}
}
