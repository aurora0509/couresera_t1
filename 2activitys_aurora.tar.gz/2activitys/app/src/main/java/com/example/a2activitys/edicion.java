package com.example.a2activitys;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

public class edicion extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_edicion);
    }

    ///metodo edicion regresa
    public void editar(View view) {
        Intent editar = new Intent(this, MainActivity.class);
        startActivity(editar);

    }
}