package com.example.semana3;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {
    private RecyclerView recyclerViewMascota;
    private RecyclerViewAdaptador adaptadorMascota;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        recyclerViewMascota=(RecyclerView)findViewById(R.id.recyclerMascota);
        recyclerViewMascota.setLayoutManager(new LinearLayoutManager(this));

        adaptadorMascota= new RecyclerViewAdaptador(obtenerMascotas()) {
            @Override
            public void onBindViewHolder(@NonNull ViewHolder holder, int position) {

            }
        };
        recyclerViewMascota.setAdapter(adaptadorMascota);
    }
    public List<MascotaModelo> obtenerMascotas(){
        List<MascotaModelo> mascota=new ArrayList<>();
        mascota.add(new MascotaModelo("chiquis","shiba inu",R.drawable.chiqui));
        return mascota;
    }
}
