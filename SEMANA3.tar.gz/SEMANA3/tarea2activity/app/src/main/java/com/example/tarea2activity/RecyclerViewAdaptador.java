package com.example.tarea2activity;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class RecyclerViewAdaptador extends RecyclerView.Adapter<RecyclerViewAdaptador.ViewHolder> {

    public static class ViewHolder extends RecyclerView.ViewHolder{
        private TextView mascota,rasa;
        ImageView fotoMascota;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            mascota=(TextView)itemView.findViewById(R.id.tvMascota);
            rasa=(TextView)itemView.findViewById(R.id.tvRaza);
            fotoMascota=(ImageView) itemView.findViewById(R.id.imgMascota);
        }
    }

    public List<MascotaModelo> mascotaLista;

    public RecyclerViewAdaptador(List<MascotaModelo> mascotaLista) {
        this.mascotaLista = mascotaLista;
    }
    @Override
    public  ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view= LayoutInflater.from(parent.getContext()).inflate(R.layout.item_mascota,parent,false);
        ViewHolder viewHolder=new ViewHolder(view);
        return viewHolder;

    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {

    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position, @NonNull List<Object> payloads) {
        super.onBindViewHolder(holder, position, payloads);
        holder.mascota.setText(mascotaLista.get(position).getMascota());
        holder.rasa.setText(mascotaLista.get(position).getRasa());
        holder.fotoMascota.setImageResource(mascotaLista.get(position).getFotoMascota());
    }
    @Override
    public int getItemCount(){
        return mascotaLista.size();
    }
}
