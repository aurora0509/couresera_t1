package com.example.tarea2activity;

public class MascotaModelo {
    private String mascota,rasa;
    private  int fotoMascota;

    public MascotaModelo() {
    }

    public MascotaModelo(String mascota, String rasa, int fotoMascota) {
        this.mascota = mascota;
        this.rasa = rasa;
        this.fotoMascota = fotoMascota;
    }

    public String getMascota() {
        return mascota;
    }

    public void setMascota(String mascota) {
        this.mascota = mascota;
    }

    public String getRasa() {
        return rasa;
    }

    public void setRasa(String rasa) {
        this.rasa = rasa;
    }

    public int getFotoMascota() {
        return fotoMascota;
    }

    public void setFotoMascota(int fotoMascota) {
        this.fotoMascota = fotoMascota;
    }
}
